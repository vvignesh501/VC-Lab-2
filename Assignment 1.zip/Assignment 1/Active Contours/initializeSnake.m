
function [x, y] = initializeSnake(I)

% Show figure

figure;
imshow(I)

% Get initial points
[x1,y1]=getpts();

[X,Y]=size(x1);

x1(X)=x1(1);
y1(X)=y1(1);
initial_pts=[x1,y1];
initial_pts=initial_pts';
total_pts=length(initial_pts);

coord = 1:total_pts;
query_pts = 1:0.1:total_pts;
interpolated_pts = spline(coord,initial_pts,query_pts);
x = interpolated_pts(1,:);
y = interpolated_pts(2,:);

plot(x,y,'-b','LineWidth',2);

end

