function [newX, newY] = iterate(Ainv,x,y, Eext, gamma, kappa)

% Get fx and fy
[fx,fy]=gradient(Eext);

% Iterate
newX = Ainv* (gamma*x - kappa*interp2(fx,x,y,'linear'));
newY = Ainv * (gamma*y - kappa*interp2(fy,x,y,'linear'));

end

