function [Ainv] = getInternalEnergyMatrixBonus(I, x,y, alpha, beta, gamma,kappa)

X=x;
Y=y;

%Second Order Derviation
der11=-2*ones(X,1);
der12=1*ones(X-1,1);
der13=1*ones(X+1,1);


double_derivative=diag(der11)+ diag(der12)+diag(der13);
double_derivative(1,X)=1;
double_derivative(X,1)=1;

%Fourth order derivation
der111=6*ones(X,1);
der112=-4*ones(X+1,1);
der113=ones(X-2,1);
der114=-4*ones(X-1,1);
der115=1*ones(X+2,1);


fourth_derivative=diag(der111)+ diag(der112,1)+ diag(der113,1)+ diag(der114,1)+ diag(der115,1);

fourth_derivative(1,X)=-4;
fourth_derivative(X,1)=-4;
fourth_derivative(1,X-1)=1;
fourth_derivative(X-1,1)=1;
fourth_derivative(2,X)=1;
fourth_derivative(X,2)=1;


%Finding the gradient for External Force
[Gx,Gy]=gradient(I);
ext=(Gx.^2+Gy.^2).^(1/2); 
[Px,Py]=gradient(ext);   


A=eye(X)+kappa*(-alpha*double_derivative+beta*fourth_derivative);
Ainv=inv(A);

old_X=x;
old_Y=y;

new_X=x;
new_Y=y;

fx=interp2(Px,new_X,new_Y); 
fy=interp2(Py,new_X,new_Y);
xt=A_inv*(gamma*old_X+kappa*fx); 
yt=A_inv*(gamma*old_Y+kappa*fy); 

end

